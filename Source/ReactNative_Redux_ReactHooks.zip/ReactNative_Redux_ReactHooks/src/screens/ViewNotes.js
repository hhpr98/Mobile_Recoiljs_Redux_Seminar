import React from 'react';
import {StyleSheet, Text, View, FlatList} from 'react-native';
import Header from '../components/Header';
import {useSelector, useDispatch} from 'react-redux';
import {List, FAB} from 'react-native-paper';
import {addNode, deleteNode} from '../redux/notesReducer';

const ViewNotes = ({navigation}) => {
  const notes = useSelector((state) => state);
  const dispatch = useDispatch();
  const addNotee = (note) => dispatch(addNode(note));
  const deleteNodee = (id) => dispatch(deleteNode(id));
  return (
    <>
      <Header title="Danh sách các ghi chú" />
      <View style={styles.container}>
        {notes?.length === 0 ? (
          <View style={styles.titleContainer}>
            <Text>Bạn chưa có ghi chú nào!!!</Text>
          </View>
        ) : (
          <FlatList
            data={notes}
            renderItem={({item}) => (
              <List.Item
                title={item.note.noteTitle}
                description={item.note.noteValue}
                descriptionNumberOfLines={1}
                titleStyle={styles.listTitle}
                onPress={() => deleteNodee(item.id)}
              />
            )}
            keyExtractor={(item) => item.id.toString()}
          />
        )}
        <FAB
          label="Thêm ghi chú"
          style={styles.fab}
          small
          icon="plus"
          onPress={() => navigation.navigate('AddNotes', {addNotee})}
        />
      </View>
    </>
  );
};

export default ViewNotes;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 10,
    paddingVertical: 20,
  },
  titleContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  title: {
    fontSize: 20,
  },
  fab: {
    position: 'absolute',
    margin: 20,
    right: 0,
    bottom: 10,
  },
  listTitle: {
    fontSize: 20,
  },
});
